def function_name(*args):
    """
    Optimized solution.

    Args:
        args: List all function parameters here with expected types.

    Returns:
        Return type and description.
    """
    # Write the actual solution here
    return None  # Replace this with the correct return value
